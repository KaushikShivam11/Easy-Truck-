sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/IconPool",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Token"
], function (Controller, IconPool, MessageToast, JSONModel, Fragment, MessageBox, Filter, FilterOperator, Token) {
	"use strict";

	return Controller.extend("ZEasy_Creation.ZEasy_Creation.controller.Main", {
		bSTOFlag: false,

		oSalesOrders: {},
		onInit: function () {
			var oSTOModel = new JSONModel();
			this.getOwnerComponent().setModel(oSTOModel, "STOModel");
			oSTOModel.setProperty("/STOFlag", this.bSTOFlag);

			this.volumeUOM = "";
			this.custOrdMainUOM = "";
			this.aSalesOrderNumber = [];
			IconPool.registerFont({
				fontFamily: "BusinessSuiteInAppSymbols",
				fontURI: jQuery.sap.getModulePath("sap.ushell.themes.base.fonts")
			});

			var oFilter = this.getView().byId("filterData");
			oFilter.addEventDelegate({
				"onAfterRendering": function (oEvent) {
					var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var oButton = oEvent.srcControl._oSearchButton;
					oButton.setText(oResourceBundle.getText("search_button"));
					oButton.setType("Accept");
				}.bind(this)
			});

			var oFilterRev = this.getView().byId("filterTripRev");
			oFilterRev.addEventDelegate({
				"onAfterRendering": function (oEvent) {
					var oResourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					var oButton = oEvent.srcControl._oSearchButton;
					oButton.setText(oResourceBundle.getText("search_button_rev"));
					oButton.setType("Accept");
				}.bind(this)
			});
			var ODataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZOGS_TRUCK_SRV");
			//ODataModel.read("/ZOGS_TEC_SO_LST");
			this.getView().setModel(ODataModel);

			this.otherDataBackendCustRef = {};
			this.selectTab = "Reg";
		},

		onSTOChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			this.bSTOFlag = (oSelectedItem.getKey() === "STO" ? true : false);

			if (!this.getView().byId("compartmentInfoTable").getVisible()) {
				this.getView().getModel("STOModel").setProperty("/STOFlag", this.bSTOFlag);
			}
		},

		onSearch: function () {
			this.oSalesOrders = {};
			var oTable = this.getView().byId("compartmentInfoTable");

			if ((oTable.getItems().length > 0 & this.byId("compartmentInfoTable").getVisible()) || (oTable.getColumns().length > 4 & this.byId(
					"compartmentInfoTable").getVisible())) {
				MessageBox.confirm("Unsaved Data will be lost. Do you want to Continue" + "?", {
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.OK) {
							this.getView().getModel("STOModel").setProperty("/STOFlag", this.bSTOFlag);
							this.byId("driverName").setValue("");
							for (var l = 0; l < oTable.getItems().length; l++) {
								oTable.removeItem(l);
								l--;
							}
							if (oTable.getColumns().length > 4) {
								for (var c = 4; c < oTable.getColumns().length; c++) {
									oTable.removeColumn(c);
									c--;
								}
							}

							this.getMainData();
						} else {
							MessageToast.show("Canceled!!", {
								duration: 500
							});
							return;
						}
					}.bind(this)
				});
			} else {
				for (var l = 0; l < oTable.getItems().length; l++) {
					oTable.removeItem(l);
					l--;
				}
				if (oTable.getColumns().length > 4) {
					for (var c = 4; c < oTable.getColumns().length; c++) {
						oTable.removeColumn(c);
						c--;
					}
				}
				this.getMainData();
			}
		},

		getMainData: function () {
			this.byId("compartmentInfoTable").setVisible(false);

			var truckNum = this.byId("truckNum").getValue();
			var isoNum = this.byId("isoNum").getValue();
			//var driverNum = this.byId("driverNum").getValue();

			var oTable = this.getView().byId("compartmentInfoTable");

			if (truckNum === "" & isoNum === "") {
				this.byId("truckNum").setValueState("Error");
				this.byId("isoNum").setValueState("Error");
				/*this.byId("driverNum").setValueState("Error");*/
				var msg = "Please input any of above fields!!";
				MessageToast.show(msg);
				return;
			} else {
				this.getView().setBusy(true);
				MessageToast.show("Searching...");
				this.byId("truckNum").setValueState("None");
				this.byId("isoNum").setValueState("None");

				var oJsonModel = new JSONModel();
				var oDatamodel = this.getView().getModel();

				var sKey = oDatamodel.createKey("/Trucks", {
					TruckNo: this.byId("truckNum").getValue(),
					IsoContainer: this.byId("isoNum").getValue(),
					InputUom: ""
						//	DriverName: this.byId("driverNum").getValue()
				});

				oDatamodel.read(sKey, {
					success: function (oReq, oRes) {

						if (oRes.headers["sap-message"] !== undefined)
							if (JSON.parse(oRes.headers["sap-message"]).code === "CUSTOM/888")
								MessageBox.confirm(JSON.parse(oRes.headers["sap-message"]).message, {
									onClose: function (oAction) {
										if (oAction === MessageBox.Action.OK) {
											this.byId("compartmentInfoTable").setVisible(true);
											this.byId("btnCreateTrip").setVisible(true);
											this.byId("btnVal").setVisible(true);
											this.byId("btnCnTrip").setVisible(false);
										} else {
											MessageToast.show("Canceled!!", {
												duration: 500
											});
											this.searchAgain = false;
										}
									}.bind(this)
								});
							else {
								this.byId("compartmentInfoTable").setVisible(true);
								this.byId("btnCreateTrip").setVisible(true);
								this.byId("btnVal").setVisible(true);
								this.byId("btnCnTrip").setVisible(false);
							}
						else {
							this.byId("compartmentInfoTable").setVisible(true);
							this.byId("btnCreateTrip").setVisible(true);
							this.byId("btnVal").setVisible(true);
							this.byId("btnCnTrip").setVisible(false);
						}
						this.searchAgain = true;

						this.byId("truckNum").setValue(oRes.data.TruckNo);

						this.byId("overFlowFt").setVisible(true);
						oJsonModel.setData(oRes.data);
						this.getView().setModel(oJsonModel, "jsonModel");
						this.volumeUOM = oJsonModel.getData().UOM;
						for (var i = 0; i < oJsonModel.getData().NoOfCompartments; i++) {
							var oCol = new sap.m.Column({
								minScreenWidth: "Tablet",
								demandPopin: true,
								popinDisplay: "Inline",
								vAlign: "Middle",
								hAlign: "Center",
								header: new sap.m.FlexBox({
									alignItems: "Center",
									direction: "Column",
									justifyContent: "Center",
									items: [new sap.m.Text({
											text: "C" + (i + 1) + " (Compartment)",
											textAlign: "Center"
										}),
										new sap.m.Text({
											text: oJsonModel.getData()["C" + (i + 1)] + " " + oJsonModel.getData().UOM + " (Max. Capacity)",
											textAlign: "Center"
										}),
										new sap.m.Text({
											text: "Comp. Qty"
										})
									]
								})
							});
							oTable.addColumn(oCol);
						}

						var oColDelete = new sap.m.Column({
							minScreenWidth: "Tablet",
							demandPopin: true,
							popinDisplay: "Inline",
							vAlign: "Middle",
							hAlign: "Center",
							width: "2em",
							header: new sap.m.Text({
								text: ""
							})
						});
						oTable.addColumn(oColDelete);

						var oCell = [];
						this.noOfCompartments = oJsonModel.getData().NoOfCompartments;
						this.totalVol = oJsonModel.getData().TotalVolume;
						this.driverNm = oJsonModel.getData().DriverName;
						this.truckNum = oJsonModel.getData().TruckNo;

						this.isoNum = this.byId("isoNum").getValue();
						//this.driverFilterVal = this.byId("driverNum").getValue();
						this.uom = oJsonModel.getData().UOM;

						for (var k = 0; k < (4 + this.noOfCompartments); k++) {

							if (k === 0) {
								oCell.push(new sap.m.Input({
									value: "",
									showValueHelp: true,
									valueHelpRequest: [this.onValueHelpMainOkPress, this],
									valueHelpOnly: true
								}));
							}

							if (k === 2) {
								oCell.push(new sap.m.MultiInput({
									showValueHelp: true,
									valueHelpRequest: [this.onValueHelpPurchase, this],
									valueHelpOnly: true,
									tokenUpdate: [this.onTokenUpdate, this]
								}));
							}

							if (k !== 1 & k !== 0 & k !== 2 & k !== 3) {
								oCell.push(new sap.m.Input({
									value: "",
									width: "7em",
									type: "Text",
									liveChange: [this.onQtyChange, this],
									editable: false
								}));
							}
							if (k === 1 || k === 3) {
								oCell.push(new sap.m.Text({
									text: ""
								}));
							}

							if (k === (3 + this.noOfCompartments)) {
								oCell.push(new sap.ui.core.Icon({
									src: "sap-icon://delete",
									press: [this.onDeleteMainTableRow, this]
								}));
							}

							var aColList = new sap.m.ColumnListItem({
								cells: oCell
							});
						}
						oTable.addItem(aColList);
						this.getView().setBusy(false);
					}.bind(this),
					error: function (oError) {
						this.getView().setBusy(false);
						var msgCodeData = JSON.parse(oError.responseText).error.code;
						var msgData = JSON.parse(oError.responseText).error.message.value;
						if (msgCodeData !== "CUSTOM/999") {
							MessageToast.show(msgData);
							return;
						}

						/*if (this.byId("truckNum").getValue().trim() === "") {
							this.byId("truckNum").setValueState("Error");
							MessageToast.show("Please enter valid Truck Number for Create Truck!!!");
							return;
						} else {
							this.byId("truckNum").setValueState("None");
						}*/

						MessageBox.confirm(msgData.replace(/'/g, "") + ". Do you wish to create the truck " + "?", {
							onClose: function (oAction) {
								if (oAction === MessageBox.Action.OK) {
									this.onPressCreateTruck();
								} else {
									MessageToast.show("Canceled!!", {
										duration: 500
									});
								}
							}.bind(this)
						});
					}.bind(this)
				});

			}
		},

		onTokenUpdate: function (oEvent) {

			var oTable = this.byId("compartmentInfoTable");

			for (var t = 0; t < oTable.getItems().length; t++) {

				var tokenLength = oTable.getItems()[t].getCells()[1].getTokens().length;
				if (oEvent.getSource().getParent().getId() === oTable.getItems()[t].getId()) {
					if (oEvent.getParameter("type") === "removed") {
						tokenLength--;
					}
				}
				if (tokenLength !== 0) {
					return;
				}
			}

			var ordNum = oTable.getItems()[0].getCells()[2].getText().split("(")[0];
			var ordItemNo = oTable.getItems()[0].getCells()[2].getText().split("(")[1].replace(")", "");
			this.onValueHelpCustomerRefPurchase(oEvent, ordNum, ordItemNo, "");

		},

		getMainDataUOM: function (uom) {

			if (this.volumeUOM === uom)
				return;

			this.getView().setBusy(false);

			this.volumeUOM = uom;

			var oTable = this.getView().byId("compartmentInfoTable");

			this.getView().setBusy(true);
			MessageToast.show("Updating UOM...");

			var oJsonModel = new JSONModel();
			var oDatamodel = this.getView().getModel();

			var sKey = oDatamodel.createKey("/Trucks", {
				TruckNo: this.byId("truckNum").getValue(),
				IsoContainer: this.byId("isoNum").getValue(),
				InputUom: this.volumeUOM
			});

			for (var t = 4; t < oTable.getColumns().length; t++) {
				oTable.removeColumn(t);
				t--;
			}

			oDatamodel.read(sKey, {
				success: function (oReq, oRes) {
					if (oRes.headers["sap-message"] !== undefined)
						if (JSON.parse(oRes.headers["sap-message"]).code === "CUSTOM/888")
							MessageBox.confirm(JSON.parse(oRes.headers["sap-message"]).message, {
								onClose: function (oAction) {
									if (oAction === MessageBox.Action.OK) {
										this.byId("compartmentInfoTable").setVisible(true);
										this.byId("btnCreateTrip").setVisible(true);
										this.byId("btnVal").setVisible(true);
										this.byId("btnCnTrip").setVisible(false);
									} else {
										MessageToast.show("Canceled!!", {
											duration: 500
										});
										this.searchAgain = false;
									}
								}.bind(this)
							});
						else {
							this.byId("compartmentInfoTable").setVisible(true);
							this.byId("btnCreateTrip").setVisible(true);
							this.byId("btnVal").setVisible(true);
							this.byId("btnCnTrip").setVisible(false);
						}
					else {
						this.byId("compartmentInfoTable").setVisible(true);
						this.byId("btnCreateTrip").setVisible(true);
						this.byId("btnVal").setVisible(true);
						this.byId("btnCnTrip").setVisible(false);
					}
					this.searchAgain = true;

					this.byId("truckNum").setValue(oRes.data.TruckNo);

					this.byId("overFlowFt").setVisible(true);
					oJsonModel.setData(oRes.data);
					this.getView().setModel(oJsonModel, "jsonModel");

					for (var i = 0; i < oJsonModel.getData().NoOfCompartments; i++) {
						var oCol = new sap.m.Column({
							minScreenWidth: "Tablet",
							demandPopin: true,
							popinDisplay: "Inline",
							vAlign: "Middle",
							hAlign: "Center",
							header: new sap.m.FlexBox({
								alignItems: "Start",
								direction: "Column",
								items: [new sap.m.Text({
										text: "C" + (i + 1) + " (Compartment)"
									}),
									new sap.m.Text({
										text: oJsonModel.getData()["C" + (i + 1)] + " " + oJsonModel.getData().UOM + " (Max. Capacity)"
									}),
									new sap.m.Text({
										text: "Comp. Qty"
									})
								]
							})
						});
						oTable.addColumn(oCol);
					}

					var oColDelete = new sap.m.Column({
						minScreenWidth: "Tablet",
						demandPopin: true,
						popinDisplay: "Inline",
						vAlign: "Middle",
						hAlign: "Center",
						width: "2em",
						header: new sap.m.Text({
							text: ""
						})
					});
					oTable.addColumn(oColDelete);

					this.noOfCompartments = oJsonModel.getData().NoOfCompartments;
					this.totalVol = oJsonModel.getData().TotalVolume;
					this.driverNm = oJsonModel.getData().DriverName;
					this.truckNum = oJsonModel.getData().TruckNo;

					this.isoNum = this.byId("isoNum").getValue();
					//this.driverFilterVal = this.byId("driverNum").getValue();
					this.uom = oJsonModel.getData().UOM;

					this.getView().setBusy(false);
				}.bind(this),
				error: function (oError) {
					this.getView().setBusy(false);
					var msgCodeData = JSON.parse(oError.responseText).error.code;
					var msgData = JSON.parse(oError.responseText).error.message.value;
					if (msgCodeData !== "CUSTOM/999") {
						MessageToast.show(msgData);
						return;
					}

					/*if (this.byId("truckNum").getValue().trim() === "") {
						this.byId("truckNum").setValueState("Error");
						MessageToast.show("Please enter valid Truck Number for Create Truck!!!");
						return;
					} else {
						this.byId("truckNum").setValueState("None");
					}*/

					MessageBox.confirm(msgData.replace(/'/g, "") + ". Do you wish to create the truck " + "?", {
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {
								this.onPressCreateTruck();
							} else {
								MessageToast.show("Canceled!!", {
									duration: 500
								});
							}
						}.bind(this)
					});
				}.bind(this)
			});

		},

		onDriverF4: function () {
			var oDriverModel = new JSONModel();
			if (!this.oDriverF4) {
				this.oDriverF4 = sap.ui.xmlfragment("ZEasy_Creation.ZEasy_Creation.Fragments.driverf4", this);
				this.getView().addDependent(this.oDriverF4);
			}
			this.getView().getModel().read("/ZOGS_TEC_DRIVER_LST", {
				success: function (oData) {
					oDriverModel.setData(oData.results);
					this.getView().setModel(oDriverModel, "driverModel");
				}.bind(this)
			});
			this.oDriverF4.open();
		},

		onDriverSelect: function (oEvent) {
			var oSource = oEvent.getSource();
			this.getView().byId("driverName").setValue(oEvent.getParameter("selectedItem").getBindingContext("driverModel").getObject().DriverName);
			this.sDriver = oEvent.getParameter("selectedItem").getBindingContext("driverModel").getObject().DriverCode;
		},

		handleDriverSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new Filter("DriverName", FilterOperator.Contains, sValue);
			var oFilterCode = new Filter("DriverCode", FilterOperator.Contains, sValue);
			var oFilterPersonnel = new Filter("PersonnelNumber", FilterOperator.Contains, sValue);
			var oFilter = new Filter({
				filters: [oFilterName, oFilterCode, oFilterPersonnel],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		onTruckF4: function (oEvent) {
			this.oTruckSource = oEvent.getSource();
			var oTruckModel = new JSONModel();
			if (!this.oTruckF4) {
				this.oTruckF4 = sap.ui.xmlfragment("ZEasy_Creation.ZEasy_Creation.Fragments.TruckF4", this);
				this.getView().addDependent(this.oTruckF4);
			}
			this.getView().getModel().read("/ZOGS_TEC_TRUCK_LST", {
				success: function (oData) {
					oTruckModel.setData(oData.results);
					this.getView().setModel(oTruckModel, "truckModel");
				}.bind(this)
			});
			this.oTruckF4.open();
		},

		onTruckF4Select: function (oEvent) {
			var oSource = oEvent.getSource();
			this.oTruckSource.setValue(oEvent.getParameter("selectedItem").getBindingContext("truckModel").getObject().TruckNo);
		},

		handleTruckSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("TruckNo", FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		onTransporterF4: function (oEvent) {
			this.TransporterSource = oEvent.getSource();
			var oTransporterModel = new JSONModel();
			if (!this.oTransporterF4) {
				this.oTransporterF4 = sap.ui.xmlfragment("ZEasy_Creation.ZEasy_Creation.Fragments.TransporterF4", this);
				this.getView().addDependent(this.oTransporterF4);
			}
			this.getView().getModel().read("/ZOGS_C_TEC_VENDOR", {
				success: function (oData) {
					oTransporterModel.setData(oData.results);
					this.getView().setModel(oTransporterModel, "transporterModel");
				}.bind(this)
			});
			this.oTransporterF4.open();
		},

		onTransporterF4Select: function (oEvent) {
			this.TransporterSource.setValue(oEvent.getParameter("selectedItem").getBindingContext("transporterModel").getObject().VendorTxt);
			this.sVendor = oEvent.getParameter("selectedItem").getBindingContext("transporterModel").getObject().Vendor;
		},

		onCarrierF4: function (oEvent) {
			this.TransporterSource = oEvent.getSource();
			var oTransporterModel = new JSONModel();
			if (!this.oTransporterF4) {
				this.oTransporterF4 = sap.ui.xmlfragment("ZEasy_Creation.ZEasy_Creation.Fragments.TransporterF4", this);
				this.getView().addDependent(this.oTransporterF4);
			}
			this.getView().getModel().read("/ZOGS_C_TEC_VENDOR", {
				success: function (oData) {
					oTransporterModel.setData(oData.results);
					this.getView().setModel(oTransporterModel, "transporterModel");
				}.bind(this)
			});
			this.oTransporterF4.open();
		},

		onPressCreateDriver: function () {
			if (!this.oCreateDriverF4) {
				this.oCreateDriverF4 = sap.ui.xmlfragment("idCreateDriver", "ZEasy_Creation.ZEasy_Creation.Fragments.CreateDriverF4", this);
				this.getView().addDependent(this.oCreateDriverF4);
			}
			this.oCreateDriverF4.open();
		},

		onCreateDriverClose: function () {
			this.oCreateDriverF4.close();
			sap.ui.core.Fragment.byId("idCreateDriver", "idFirstName").setValue("");
			sap.ui.core.Fragment.byId("idCreateDriver", "idLastName").setValue("");
		},

		onCreateDriver: function () {
			this.getView().setBusy(true);
			var sLastName = sap.ui.core.Fragment.byId("idCreateDriver", "idLastName").getValue();
			if (sLastName === "") {
				MessageBox.error("Last Name is required");
				return;
			}
			var oDriver = {
				"FirstName": sap.ui.core.Fragment.byId("idCreateDriver", "idFirstName").getValue(),
				"LastName": sap.ui.core.Fragment.byId("idCreateDriver", "idLastName").getValue(),
				"CarrierID": this.sVendor
			};
			this.getView().getModel().create("/Drivers", oDriver, {
				success: function (oData, oResponse) {
					MessageBox.success(JSON.parse(oResponse.headers["sap-message"]).message);
					this.oCreateDriverF4.close();
					this.getView().setBusy(false);
					sap.ui.core.Fragment.byId("idCreateDriver", "idFirstName").setValue("");
					sap.ui.core.Fragment.byId("idCreateDriver", "idLastName").setValue("");
				}.bind(this),
				error: function (oError) {
					MessageBox.error(JSON.parse(oError.responseText).error.message.value);
					this.oCreateDriverF4.close();
					this.getView().setBusy(false);
					sap.ui.core.Fragment.byId("idCreateDriver", "idFirstName").setValue("");
					sap.ui.core.Fragment.byId("idCreateDriver", "idLastName").setValue("");
				}.bind(this)
			});
		},

		onOrderF4: function () {
			var oOrderModel = new JSONModel();
			if (!this.oOrderF4) {
				this.oOrderF4 = sap.ui.xmlfragment("ZEasy_Creation.ZEasy_Creation.Fragments.CustomerOrderReference", this);
				this.getView().addDependent(this.oOrderF4);
			}
			this.getView().getModel().read("/ZOGS_TEC_SO_LST('L')/Set", {
				success: function (oData) {
					oOrderModel.setData(oData.results);
					this.getView().setModel(oOrderModel, "orderModel");
				}.bind(this)
			});
			this.oOrderF4.open();
		},

		onOrderSelect: function (oEvent) {
			this.getView().byId("custOrdNum").setValue(oEvent.getParameter("selectedItem").getBindingContext("orderModel").getObject().SalesOrderNo);
		},

		handleOrderSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("SalesOrderNo", FilterOperator.Contains, sValue);
			var oFilterCust = new Filter("CustomerReference", FilterOperator.Contains, sValue);
			var oFilterOr = new Filter({
				filters: [oFilter, oFilterCust],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterOr]);
		},

		handleTranporterSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Vendor", FilterOperator.Contains, sValue);
			var oFilterTxt = new Filter("VendorTxt", FilterOperator.Contains, sValue);
			var oFilterOr = new Filter({
				filters: [oFilter, oFilterTxt],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterOr]);
		},

		onValueHelpPurchase: function (oEvent) {

			if (!this.valueHelPurchaseDialog) {
				this.valueHelPurchaseDialog = sap.ui.xmlfragment(
					"ZEasy_Creation.ZEasy_Creation.Fragments.PurchaseHelp",
					this
				);
				this.getView().addDependent(this.valueHelPurchaseDialog);
			}

			this.getPrdHelp_Data("/ZOGS_C_TEC_PURGRP", "purchaseGrpPrdHelpData");

			sap.ui.getCore().byId("vendorPrdHelp").setValue();
			sap.ui.getCore().byId("vendorPrdHelp").setValueStateText();

			sap.ui.getCore().byId("plantPrdHelp").setValue();
			sap.ui.getCore().byId("plantPrdHelp").setValueStateText();

			sap.ui.getCore().byId("purchasingGrpPrdHelp").setSelectedKey("");
			sap.ui.getCore().byId("purchaseOrderHelp").setValue("");

			this.getPrdHelpTopData("/ZOGS_C_TEC_VENDOR", "vendorPrdHelpData", "Vendor");
			this.getPrdHelpTopData("/ZOGS_C_TEC_PLANT", "plantPrdHelpData", "Plant");

			var oCust = new sap.ui.core.CustomData();
			oCust.setKey("oTableField");
			oCust.setValue(oEvent.getSource().getParent().getId());
			this.valueHelPurchaseDialog.addCustomData(oCust);

			this.valueHelPurchaseDialog.open();
		},

		getVendorPrdHelp: function () {
			if (!this.valueHelpVendorDialog) {
				this.valueHelpVendorDialog = sap.ui.xmlfragment(
					"ZEasy_Creation.ZEasy_Creation.Fragments.ValueHelpVendor",
					this
				);
				this.getView().addDependent(this.valueHelpVendorDialog);
			}
			this.valueHelpVendorDialog.open();
		},

		handleSearchVendor: function (oEvent) {
			this.getPrdHelpData("/ZOGS_C_TEC_VENDOR", "vendorPrdHelpData", oEvent.getParameter("value"), "VendorTxt", "Vendor");
		},

		onConfirmHelpVendor: function (oEvent) {
			sap.ui.getCore().byId("vendorPrdHelp").setValue(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
			sap.ui.getCore().byId("vendorPrdHelp").setValueStateText(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
		},

		getPlantPrdHelp: function () {
			if (!this.valueHelpPlantDialog) {
				this.valueHelpPlantDialog = sap.ui.xmlfragment(
					"ZEasy_Creation.ZEasy_Creation.Fragments.ValueHelpPlant",
					this
				);
				this.getView().addDependent(this.valueHelpPlantDialog);
			}

			this.valueHelpPlantDialog.open();
		},

		handleSearchPlant: function (oEvent) {
			this.getPrdHelpData("/ZOGS_C_TEC_PLANT", "plantPrdHelpData", oEvent.getParameter("value"), "PlantTxt", "Plant");
		},

		onConfirmHelpPlant: function (oEvent) {
			sap.ui.getCore().byId("plantPrdHelp").setValue(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
			sap.ui.getCore().byId("plantPrdHelp").setValueStateText(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
		},

		getPrdHelpTopData: function (serviceName, modelName, type) {
			this.getView().setBusy(true);
			var oJsonModel = new JSONModel();
			var oModel = this.getView().getModel();

			oModel.read(serviceName, {
				urlParameters: {
					"$orderby": type,
					"$top": 100
				},
				success: function (sMsg) {
					this.getView().setBusy(false);
					oJsonModel.setData(sMsg.results);
					this.getView().setModel(oJsonModel, modelName);
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					MessageToast.show("Error at Service: " + serviceName);
				}.bind(this)
			});
		},

		getPrdHelpData_: function (serviceName, modelName) {
			this.getView().setBusy(true);

			var oJsonModel = new JSONModel();
			var oModel = this.getView().getModel();

			oModel.read(serviceName, {
				urlParameters: {
					"$orderby": "PurchasingGroup"
				},
				success: function (sMsg) {
					this.getView().setBusy(false);

					oJsonModel.setData(sMsg.results);
					this.getView().setModel(oJsonModel, modelName);
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					MessageToast.show("Error at Service: " + serviceName);
				}.bind(this)
			});
		},

		getPrdHelpData: function (serviceName, modelName, value, firstFilter, SecondFilter) {
			this.getView().setBusy(true);

			var oJsonModel = new JSONModel();
			var oModel = this.getView().getModel();

			var txtInfo = new Filter(firstFilter, FilterOperator.Contains, value);
			var keyInfo = new Filter(SecondFilter, FilterOperator.Contains, value);

			var allFilters = new Filter({
				filters: [txtInfo, keyInfo],
				and: false
			});

			oModel.read(serviceName, {
				filters: [allFilters],
				urlParameters: {
					"$orderby": SecondFilter
				},
				success: function (sMsg) {
					this.getView().setBusy(false);
					oJsonModel.setData(sMsg.results);
					this.getView().setModel(oJsonModel, modelName);
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					MessageToast.show("Error at Service: " + serviceName);
				}.bind(this)
			});
		},

		getPrdHelp_Data: function (serviceName, modelName) {
			this.getView().setBusy(true);
			var oJsonModel = new JSONModel();
			var oModel = this.getView().getModel();

			oModel.read(serviceName, {
				urlParameters: {
					"$orderby": "PurchasingGroup"
				},
				success: function (sMsg) {
					this.getView().setBusy(false);
					oJsonModel.setData(sMsg.results);
					this.getView().setModel(oJsonModel, modelName);
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					MessageToast.show("Error at Service: " + serviceName);
				}.bind(this)
			});
		},

		checkPurchaseGrpPrdHelp: function () {
			var inputData = sap.ui.getCore().byId("purchasingGrpPrdHelp");

			if (inputData.getValue().trim() === "") {
				inputData.setValueState("None");
				return;
			}

			var oModelData = this.valueHelPurchaseDialog.getModel("purchaseGrpPrdHelpData").getData();

			for (var i = 0; i < oModelData.length; i++) {
				if (inputData.getValue().trim() === oModelData[i].PurchasingGroupTxt.trim()) {
					inputData.setValueState("None");
					break;
				} else {
					inputData.setValueState("Error");
				}
			}
		},

		okPurchase: function (oEvent) {

			var sRowId = oEvent.getSource().data();
			if (sap.ui.getCore().byId("vendorPrdHelp").getValue().trim() === "") {
				sap.ui.getCore().byId("vendorPrdHelp").setValueState("Error");
				MessageToast.show("Please Input Vendor!!");
				return;
			} else {
				sap.ui.getCore().byId("vendorPrdHelp").setValueState("None");
			}

			if (sap.ui.getCore().byId("plantPrdHelp").getValueState() === "Error" ||
				sap.ui.getCore().byId("purchasingGrpPrdHelp").getValueState() === "Error") {
				MessageToast.show("Please resolve error!!");
				return;
			}

			var oModel = this.getView().getModel();
			var oJsonModel = new JSONModel();

			var vendorInfo = new Filter("Vendor", FilterOperator.EQ, sap.ui.getCore().byId("vendorPrdHelp").getValueStateText());
			//var plantInfo = new Filter("Plant", FilterOperator.EQ, sap.ui.getCore().byId("plantPrdHelp").getValueStateText());
			//var purchaseGrpInfo = new Filter("PurchasingGroup", FilterOperator.EQ, sap.ui.getCore().byId("purchasingGrpPrdHelp").getSelectedKey());
			//var docInfo = new Filter("DocNumber", FilterOperator.EQ, sap.ui.getCore().byId("purchaseOrderHelp").getValue());

			var objectFilter = [vendorInfo];

			if (sap.ui.getCore().byId("plantPrdHelp").getValueStateText() !== '') {
				objectFilter.push(new Filter("Plant", FilterOperator.EQ, sap.ui.getCore().byId("plantPrdHelp").getValueStateText()));
			}

			if (sap.ui.getCore().byId("purchasingGrpPrdHelp").getSelectedKey() !== '') {
				objectFilter.push(new Filter("PurchasingGroup", FilterOperator.EQ, sap.ui.getCore().byId("purchasingGrpPrdHelp").getSelectedKey()));
			}

			if (sap.ui.getCore().byId("purchaseOrderHelp").getValue() !== '') {
				objectFilter.push(new Filter("DocNumber", FilterOperator.EQ, sap.ui.getCore().byId("purchaseOrderHelp").getValue()));
			}

			this.getView().setBusy(true);
			oModel.read('/ZOGS_C_TEC_PO', {
				filters: objectFilter,
				success: function (sMsg) {
					if (sMsg.results.length === 0) {
						MessageToast.show("No Data Found!!");
						this.getView().setBusy(false);
						return;
					} else {

						this.valueHelPurchaseDialog.close();
						oJsonModel.setData(sMsg.results);
						if (!this.valueHelpPurchaseContractDialog) {
							this.valueHelpPurchaseContractDialog = sap.ui.xmlfragment(
								"ZEasy_Creation.ZEasy_Creation.Fragments.ValueHelpPurchaseContract",
								this
							);
							this.getView().addDependent(this.valueHelpPurchaseContractDialog);
						}

						sap.ui.getCore().byId("purchaseOrdTable").setTitle("Select Purchase Contract " + "(Vendor: " + sap.ui.getCore().byId(
								"vendorPrdHelp").getValueStateText() + " Plant: " + sap.ui.getCore().byId("plantPrdHelp").getValueStateText() +
							" Purchasing Group: " + sap.ui.getCore().byId("purchasingGrpPrdHelp").getSelectedKey() + " Doc Number: " + sap.ui.getCore()
							.byId(
								"purchaseOrderHelp").getValue() + ")");
						this.valueHelpPurchaseContractDialog.setModel(oJsonModel, "purchaseContractData");

						this.valueHelpPurchaseContractDialog._getCancelButton().setText("Back");
						var oCust = new sap.ui.core.CustomData();
						oCust.setKey("oTableField");
						oCust.setValue(sRowId.oTableField);
						this.valueHelpPurchaseContractDialog.addCustomData(oCust);
						this.getView().setBusy(false);
						this.valueHelpPurchaseContractDialog.open();
					}
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					this.valueHelPurchaseDialog.close();
					MessageToast.show("Service Failed: ZOGS_C_TEC_PO");
				}.bind(this)
			});

		},

		cancelPurchaseOrdTable: function () {
			this.valueHelPurchaseDialog.open();
		},

		handleSearchPurchaseContract: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter1 = new Filter("DocNumber", FilterOperator.Contains, sValue);
			var oFilter2 = new Filter("DocTypeWithTxt", FilterOperator.Contains, sValue);
			var oFilter3 = new Filter("PurchasingGroupWithTxt", FilterOperator.Contains, sValue);
			var oFilter4 = new Filter("PlantWithTxt", FilterOperator.Contains, sValue);
			var aFilter = new Filter([oFilter1, oFilter2, oFilter3, oFilter4], false);

			var oBinding = oEvent.getSource().getBinding("items");

			oBinding.filter(aFilter);
		},

		onConfirmPurchaseContract: function (oEvent) {
			var oTable = this.byId("compartmentInfoTable");
			var sRowId = oEvent.getSource().data();

			var ordNum = "";
			var ordItemNo = "";

			for (var i = 0; i < oTable.getItems().length; i++) {
				if (sRowId.oTableField === oTable.getItems()[i].getId()) {
					var aToken = new Token({
						text: oEvent.getParameter("selectedItems")[0].getCells()[0].getText(),
						key: oEvent.getParameter("selectedItems")[0].getCells()[1].getText().split('(')[1][0]
					});
					oTable.getItems()[i].getCells()[1].setTokens([aToken]);
					//oTable.getItems()[i].getCells()[1].setValueStateText();

					ordNum = oTable.getItems()[i].getCells()[2].getText().split("(")[0];
					ordItemNo = oTable.getItems()[i].getCells()[2].getText().split("(")[1].replace(")", "");

					break;
				}
			}

			this.onValueHelpCustomerRefPurchase(oEvent, ordNum, ordItemNo, "X");

		},

		onPurchaseCancel: function () {
			this.valueHelPurchaseDialog.close();
		},

		onValueHelpMainOkPress: function (oEvent) {
			var oDataModel = this.getView().getModel();
			if (this.bSTOFlag) {
				var oPOModel = new JSONModel();
				this.getView().setModel(oPOModel, "POModel");
				if (!this.helpPO_dialog) {
					this.helpPO_dialog = sap.ui.xmlfragment(
						"ZEasy_Creation.ZEasy_Creation.Fragments.PO",
						this
					);
					this.getView().addDependent(this.helpPO_dialog);

				}
				this.helpPO_dialog.setBusy(true);
				oDataModel.read("/ZONGS_STO_PO_LST", {
					success: function (oData) {
						this.getView().getModel("POModel").setData(oData.results);
						this.helpPO_dialog.setBusy(false);
					}.bind(this),

					error: function () {

					}
				});
				var oCust = new sap.ui.core.CustomData();
				oCust.setKey("oTableField");
				oCust.setValue(oEvent.getSource().getParent().getId());
				this.helpPO_dialog.addCustomData(oCust);
				this.helpPO_dialog.open();
			} else {
				var oTable = this.byId("compartmentInfoTable");
				var oTableLength = oTable.getItems().length;

				var checkData = false;

				if (oTableLength === 1) {
					this.fPlant = undefined;
					this.fIncoTerms = undefined;
					this.fSalesOrg = undefined;
				} else if (oTableLength > 1) {
					for (var i = 0; i < oTableLength; i++) {

						if (oEvent.getSource().getParent().getId() === oTable.getItems()[0].getId()) {
							break;
						}

						var x = oTable.getItems()[i].getCells()[1].getText();
						if (x !== "") {
							checkData = true;
							break;
						}
					}
				}

				if (checkData === false) {
					this.fPlant = undefined;
					this.fIncoTerms = undefined;
					this.fSalesOrg = undefined;
				}

				var custRef = new Filter("CustomerReference", FilterOperator.Contains, " ");
				var delExist = new Filter("DeliveryExist", FilterOperator.EQ, " ");
				var plantCheck = new Filter("DeliveryExist", FilterOperator.EQ, " ");
				var incoTermsCheck = new Filter("DeliveryExist", FilterOperator.EQ, " ");
				var salesOrgCheck = new Filter("DeliveryExist", FilterOperator.EQ, " ");

				if (this.fPlant !== undefined) {
					plantCheck = new Filter("Plant", FilterOperator.EQ, this.fPlant);
				}

				if (this.fIncoTerms !== undefined) {
					incoTermsCheck = new Filter("IncoTerms", FilterOperator.EQ, this.fIncoTerms);
				}

				if (this.fSalesOrg !== undefined) {
					salesOrgCheck = new Filter("SalesOrg", FilterOperator.EQ, this.fSalesOrg);
				}

				var oCustomerRefModel = new JSONModel();

				/*var sKey = oDataModel.createKey("/ZOGS_TEC_SO_LST", {
					p_uom: this.uom
				});*/
				var valB2B = "";

				for (var t = 0; t < oTable.getItems().length; t++) {
					if (oTable.getItems()[t].getCells()[2].getTokens().length !== 0) {
						valB2B = "X";
						break;
					}
				}

				var sKey = oDataModel.createKey("/ZOGS_TEC_SO_LST", {
					p_is_b2b: valB2B
				});

				oDataModel.read(sKey + "/Set", {
					filters: [custRef, delExist, plantCheck, incoTermsCheck, salesOrgCheck],
					success: function (res) {
						this.helpCustomerRef.setBusy(false);

						var orderNo = [];

						if (checkData) {
							for (var t = 0; t < oTableLength - 1; t++) {
								orderNo.push(oTable.getItems()[t].getCells()[1].getText());
							}
							for (var r = 0; r < res.results.length; r++) {
								if (orderNo.includes(res.results[r].SalesOrderNo)) {
									res.results.splice(r, 1);
									r--;
								}
							}
						}

						oCustomerRefModel.setData(res.results);
						this.helpCustomerRef.setModel(oCustomerRefModel, "customerInfo");
					}.bind(this),
					error: function (err) {
						this.helpCustomerRef.setBusy(false);
						MessageToast.show("Service Error: ZOGS_TEC_SO_LST " + err);
					}.bind(this)
				});

				if (!this.helpCustomerRef) {
					this.helpCustomerRef = sap.ui.xmlfragment(
						"ZEasy_Creation.ZEasy_Creation.Fragments.ValueHelpCustomerRef",
						this
					);
					this.getView().addDependent(this.helpCustomerRef);

				}

				var oCust = new sap.ui.core.CustomData();
				oCust.setKey("oTableField");

				oCust.setValue(oEvent.getSource().getParent().getId());
				this.helpCustomerRef.addCustomData(oCust);
				this.helpCustomerRef.setBusy(true);

				this.helpCustomerRef.open();
			}
		},

		onSearchPO: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterPO = new Filter("PurchaseOrderNo", FilterOperator.Contains, sValue);
			var oTableSelect = oEvent.getSource();
			var oBinding = oTableSelect.getBinding("items");
			oBinding.filter(oFilterPO);
		},

		onCustRefOkPress: function (oEvent) {

			//var index = parseInt(.getSource().getId().split("idTaskDetails - ")[1])
			var sRowId = oEvent.getSource().data();
			var oTable = this.byId("compartmentInfoTable");
			var oRowObject = oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject();
			var sSalesOrderNumberwithItem = oRowObject.SalesOrderWithItemNo;
			if (this.oSalesOrders[sSalesOrderNumberwithItem] && oTable.getItems().length > 1) {
				MessageBox.error("Sales Order Already Choosen");
				return;
			}
			this.oSalesOrders[sSalesOrderNumberwithItem] = "1";
			this.aSalesOrderNumber.push(oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject().SalesOrderItemNo);
			for (var i = 0; i < oTable.getItems().length; i++) {
				if (sRowId.oTableField === oTable.getItems()[0].getId() & oTable.getItems().length > 1) {
					var custRef = oEvent.getParameter("selectedItems")[0].getCells()[1].getText();
					var ordNo = oEvent.getParameter("selectedItems")[0].getCells()[0].getText();
					var ordQty = oEvent.getParameter("selectedItems")[0].getCells()[2].getText();
					var plant = oEvent.getParameter("selectedItems")[0].getCells()[4].getText();
					var incoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
					var salesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();
					var sSalesOrderItemNo = oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject().SalesOrderItemNo;
					var salesQty = oEvent.getParameter("selectedItems")[0].getCells()[7].getText();
					var material = oEvent.getParameter("selectedItems")[0].getCells()[9].getText();
					var salesUOM = oEvent.getParameter("selectedItems")[0].getCells()[8].getText();

					MessageBox.confirm("If you change in this row below rows will be Deleted. Do you want to Continue" + "?", {
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {

								var maxFillingCapacity = 0;
								for (var t = 4; t < oTable.getColumns().length - 1; t++) {
									maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
								}

								if (Number(ordQty) > maxFillingCapacity) {
									MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
										onClose: function (oAct) {
											if (oAct === MessageBox.Action.OK) {

												this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
												//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
												setTimeout(function () {
													oTable.getItems()[i].getCells()[0].setValue(ordNo);

													this.otherDataBackendCustRef[i] = {
														salesQty: salesQty,
														Material: material,
														salesUOM: salesUOM,
														plant: plant,
														sSalesOrderItemNo: sSalesOrderItemNo
													};

													oTable.getItems()[i].getCells()[1].setText(custRef);
													oTable.getItems()[i].getCells()[3].setText(ordQty);
													this.fPlant = plant;
													this.fIncoTerms = incoTerms;
													this.fSalesOrg = salesOrg;

													for (var c = 4; c < oTable.getColumns().length - 1; c++) {
														oTable.getItems()[i].getCells()[c].setEditable(true);
														oTable.getItems()[i].getCells()[c].setValue("");
													}

													for (var r = 1; r < oTable.getItems().length; r++) {
														oTable.removeItem(r);
														r--;
													}
													this.checkRows();
												}.bind(this), 1500);

											} else {
												MessageToast.show("Canceled!!", {
													duration: 500
												});
											}
										}.bind(this)
									});
								} else {
									oTable.getItems()[i].getCells()[0].setValue(ordNo);

									this.otherDataBackendCustRef[i] = {
										salesQty: salesQty,
										Material: material,
										salesUOM: salesUOM,
										plant: plant,
										sSalesOrderItemNo: sSalesOrderItemNo
									};

									oTable.getItems()[i].getCells()[1].setText(custRef);
									oTable.getItems()[i].getCells()[3].setText(ordQty);
									this.fPlant = plant;
									this.fIncoTerms = incoTerms;
									this.fSalesOrg = salesOrg;

									for (var c = 4; c < oTable.getColumns().length - 1; c++) {
										oTable.getItems()[i].getCells()[c].setEditable(true);
										oTable.getItems()[i].getCells()[c].setValue("");
									}

									for (var r = 1; r < oTable.getItems().length; r++) {
										oTable.removeItem(r);
										r--;
									}
									this.checkRows();
								}

							} else {
								MessageToast.show("Canceled!!", {
									duration: 500
								});
							}
						}.bind(this)
					});
					break;
				} else if (sRowId.oTableField === oTable.getItems()[i].getId()) {

					//oTable.setBusy(true);

					var maxFillingCapacity = 0;
					var sCurrUom = oTable.getColumns()[4].getHeader().getItems()[1].getText().split(" ")[1];
					/*for (var t = 4; t < oTable.getColumns().length - 1; t++) {
						maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
						sCurrUom = oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[1];
					}*/
					var oDatamodel = this.getView().getModel();
					var sKey = oDatamodel.createKey("/Trucks", {
						TruckNo: this.byId("truckNum").getValue(),
						IsoContainer: this.byId("isoNum").getValue(),
						InputUom: oRowObject.VolumeUOM
					});
					if (sCurrUom !== oRowObject.VolumeUOM) {
						var oUOMPromise = new Promise(function (resolved) {
							oDatamodel.read(sKey, {
								success: function (oData) {
									resolved(oData);
								}
							});
						}).then(function (oData) {
							maxFillingCapacity = parseInt(oData.C1) + parseInt(oData.C2) + parseInt(oData.C3) + parseInt(oData.C4) + parseInt(oData.C5) +
								parseInt(oData.C6) + parseInt(oData.C7) + parseInt(oData.C8);
							if (Number(oRowObject.QtyInInputUOM) > maxFillingCapacity) {

								custRef = oRowObject.CustomerReference;
								salesQty = oRowObject.Quantity;
								material = oRowObject.Material;
								salesUOM = oRowObject.SalesUnitOfMeasure;
								plant = oRowObject.Plant;
								sSalesOrderItemNo = oRowObject.SalesOrderItemNo;
								ordNo = oRowObject.SalesOrderWithItemNo;
								ordQty = oRowObject.QtyInInputUOM;
								incoTerms = oRowObject.IncoTerms;
								salesOrg = oRowObject.SalesOrg;

								MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
									onClose: function (oAction) {
										if (oAction === MessageBox.Action.OK) {

											//this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
											this.getMainDataUOM(oRowObject.VolumeUOM);
											//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
											setTimeout(function () {
												oTable.getItems()[i].getCells()[0].setValue(ordNo);
												this.otherDataBackendCustRef[i] = {
													salesQty: salesQty,
													Material: material,
													salesUOM: salesUOM,
													plant: plant,
													sSalesOrderItemNo: sSalesOrderItemNo
												};

												oTable.getItems()[i].getCells()[1].setText(custRef);
												oTable.getItems()[i].getCells()[3].setText(ordQty);
												this.fPlant = plant;
												this.fIncoTerms = incoTerms;
												this.fSalesOrg = salesOrg;

												for (var c = 4; c < oTable.getColumns().length - 1; c++) {
													oTable.getItems()[i].getCells()[c].setEditable(true);
													oTable.getItems()[i].getCells()[c].setValue("");
												}
												this.checkRows();
											}.bind(this), 1500);

										} else {
											MessageToast.show("Canceled!!", {
												duration: 500
											});
										}
									}.bind(this)
								});
							} else {
								oTable.getItems()[i].getCells()[0].setValue(oRowObject.SalesOrderWithItemNo);
								this.otherDataBackendCustRef[i] = {
									salesQty: oRowObject.Quantity,
									Material: oRowObject.Material,
									salesUOM: oRowObject.SalesUnitOfMeasure,
									plant: oRowObject.Plant,
									sSalesOrderItemNo: oRowObject.SalesOrderItemNo
								};

								oTable.getItems()[i].getCells()[1].setText(oRowObject.CustomerReference);
								oTable.getItems()[i].getCells()[3].setText(oRowObject.QtyInInputUOM);
								this.fPlant = oRowObject.Plant;
								this.fIncoTerms = oRowObject.IncoTerms;
								this.fSalesOrg = oRowObject.SalesOrg;

								for (var c = 4; c < oTable.getColumns().length - 1; c++) {
									oTable.getItems()[i].getCells()[c].setEditable(true);
									oTable.getItems()[i].getCells()[c].setValue("");
								}

								this.checkRows();

								this.getMainDataUOM(oRowObject.VolumeUOM);

							}
						}.bind(this));
					} else {
						for (var t = 4; t < oTable.getColumns().length - 1; t++) {
							maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
						}
						if (Number(oRowObject.QtyInInputUOM) > maxFillingCapacity) {

							custRef = oRowObject.CustomerReference;
							salesQty = oRowObject.Quantity;
							material = oRowObject.Material;
							salesUOM = oRowObject.SalesUnitOfMeasure;
							plant = oRowObject.Plant;
							sSalesOrderItemNo = oRowObject.SalesOrderItemNo;
							ordNo = oRowObject.SalesOrderWithItemNo;
							ordQty = oRowObject.QtyInInputUOM;
							incoTerms = oRowObject.IncoTerms;
							salesOrg = oRowObject.SalesOrg;

							MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
								onClose: function (oAction) {
									if (oAction === MessageBox.Action.OK) {

										//this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
										this.getMainDataUOM(oRowObject.VolumeUOM);
										//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
										setTimeout(function () {
											oTable.getItems()[i].getCells()[0].setValue(ordNo);
											this.otherDataBackendCustRef[i] = {
												salesQty: salesQty,
												Material: material,
												salesUOM: salesUOM,
												plant: plant,
												sSalesOrderItemNo: sSalesOrderItemNo
											};

											oTable.getItems()[i].getCells()[1].setText(custRef);
											oTable.getItems()[i].getCells()[3].setText(ordQty);
											this.fPlant = plant;
											this.fIncoTerms = incoTerms;
											this.fSalesOrg = salesOrg;

											for (var c = 4; c < oTable.getColumns().length - 1; c++) {
												oTable.getItems()[i].getCells()[c].setEditable(true);
												oTable.getItems()[i].getCells()[c].setValue("");
											}
											this.checkRows();
										}.bind(this), 1500);

									} else {
										MessageToast.show("Canceled!!", {
											duration: 500
										});
									}
								}.bind(this)
							});
						} else {
							oTable.getItems()[i].getCells()[0].setValue(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
							this.otherDataBackendCustRef[i] = {
								salesQty: oEvent.getParameter("selectedItems")[0].getCells()[7].getText(),
								Material: oEvent.getParameter("selectedItems")[0].getCells()[9].getText(),
								salesUOM: oEvent.getParameter("selectedItems")[0].getCells()[8].getText(),
								plant: oEvent.getParameter("selectedItems")[0].getCells()[4].getText(),
								sSalesOrderItemNo: oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject().SalesOrderItemNo
							};

							oTable.getItems()[i].getCells()[1].setText(oEvent.getParameter("selectedItems")[0].getCells()[1].getText());
							oTable.getItems()[i].getCells()[3].setText(oEvent.getParameter("selectedItems")[0].getCells()[2].getText());
							this.fPlant = oEvent.getParameter("selectedItems")[0].getCells()[4].getText();
							this.fIncoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
							this.fSalesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();

							for (var c = 4; c < oTable.getColumns().length - 1; c++) {
								oTable.getItems()[i].getCells()[c].setEditable(true);
								oTable.getItems()[i].getCells()[c].setValue("");
							}

							this.checkRows();

							this.getMainDataUOM(oRowObject.VolumeUOM);

						}
					}

					break;
				}
			}

		},

		onPOConfirm: function (oEvent) {

			//var index = parseInt(.getSource().getId().split("idTaskDetails - ")[1])
			var sRowId = oEvent.getSource().data();
			var oTable = this.byId("compartmentInfoTable");
			var oRowObject = oEvent.getParameter("selectedItem").getBindingContext("POModel").getObject();
			//this.aSalesOrderNumber.push(oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject().SalesOrderItemNo);
			for (var i = 0; i < oTable.getItems().length; i++) {
				if (sRowId.oTableField === oTable.getItems()[0].getId() & oTable.getItems().length > 1) {
					//var custRef = oEvent.getParameter("selectedItems")[0].getCells()[1].getText();
					var ordNo = oRowObject.PurchaseOrderNo;
					var ordQty = oRowObject.QtyInInputUOM;
					var plant = oRowObject.Plant;
					//var incoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
					//var salesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();
					var sPurchaseOrderItemNo = oRowObject.PurchaseOrderItemNo;
					var sPurchaseQty = oRowObject.QtyInInputUOM;
					var material = oRowObject.Material;
					var salesUOM = oRowObject.PurchaseUnitOfMeasure;

					MessageBox.confirm("If you change in this row below rows will be Deleted. Do you want to Continue" + "?", {
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {

								var maxFillingCapacity = 0;
								for (var t = 4; t < oTable.getColumns().length - 1; t++) {
									maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
								}

								if (Number(ordQty) > maxFillingCapacity) {
									MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
										onClose: function (oAct) {
											if (oAct === MessageBox.Action.OK) {

												this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
												//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
												setTimeout(function () {
													//oTable.getItems()[i].getCells()[0].setValue(custRef);

													this.otherDataBackendCustRef[i] = {
														salesQty: sPurchaseQty,
														Material: material,
														salesUOM: salesUOM,
														plant: plant,
														sSalesOrderItemNo: sPurchaseOrderItemNo
													};

													oTable.getItems()[i].getCells()[2].setText(ordNo);
													oTable.getItems()[i].getCells()[3].setText(ordQty);
													this.fPlant = plant;
													//this.fIncoTerms = incoTerms;
													//this.fSalesOrg = salesOrg;

													for (var c = 4; c < oTable.getColumns().length - 1; c++) {
														oTable.getItems()[i].getCells()[c].setEditable(true);
														oTable.getItems()[i].getCells()[c].setValue("");
													}

													for (var r = 1; r < oTable.getItems().length; r++) {
														oTable.removeItem(r);
														r--;
													}
													this.checkRows();
												}.bind(this), 1500);

											} else {
												MessageToast.show("Canceled!!", {
													duration: 500
												});
											}
										}.bind(this)
									});
								} else {
									//	oTable.getItems()[i].getCells()[0].setValue(custRef);

									this.otherDataBackendCustRef[i] = {
										salesQty: sPurchaseQty,
										Material: material,
										salesUOM: salesUOM,
										plant: plant,
										sSalesOrderItemNo: sPurchaseOrderItemNo
									};

									oTable.getItems()[i].getCells()[2].setText(ordNo);
									oTable.getItems()[i].getCells()[3].setText(ordQty);
									this.fPlant = plant;
									//this.fIncoTerms = incoTerms;
									//this.fSalesOrg = salesOrg;

									for (var c = 4; c < oTable.getColumns().length - 1; c++) {
										oTable.getItems()[i].getCells()[c].setEditable(true);
										oTable.getItems()[i].getCells()[c].setValue("");
									}

									for (var r = 1; r < oTable.getItems().length; r++) {
										oTable.removeItem(r);
										r--;
									}
									this.checkRows();
								}

							} else {
								MessageToast.show("Canceled!!", {
									duration: 500
								});
							}
						}.bind(this)
					});
					break;
				} else if (sRowId.oTableField === oTable.getItems()[i].getId()) {

					var maxFillingCapacity = 0;
					var sCurrUom = oTable.getColumns()[4].getHeader().getItems()[1].getText().split(" ")[1];
					/*for (var t = 4; t < oTable.getColumns().length - 1; t++) {
						maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
						sCurrUom = oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[1];
					}*/
					var oDatamodel = this.getView().getModel();
					var sKey = oDatamodel.createKey("/Trucks", {
						TruckNo: this.byId("truckNum").getValue(),
						IsoContainer: this.byId("isoNum").getValue(),
						InputUom: oRowObject.VolumeUOM
					});
					if (sCurrUom !== oRowObject.VolumeUOM) {
						var oUOMPromise = new Promise(function (resolved) {
							oDatamodel.read(sKey, {
								success: function (oData) {
									resolved(oData);
								}
							});
						}).then(function (oData) {
							maxFillingCapacity = parseInt(oData.C1) + parseInt(oData.C2) + parseInt(oData.C3) + parseInt(oData.C4) + parseInt(oData.C5) +
								parseInt(oData.C6) + parseInt(oData.C7) + parseInt(oData.C8);
							if (Number(oRowObject.QtyInInputUOM) > maxFillingCapacity) {

								ordNo = oRowObject.PurchaseOrderNo;
								ordQty = oRowObject.QtyInInputUOM;
								plant = oRowObject.Plant;
								//var incoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
								//var salesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();
								sPurchaseOrderItemNo = oRowObject.PurchaseOrderItemNo;
								sPurchaseQty = oRowObject.QtyInInputUOM;
								material = oRowObject.Material;
								salesUOM = oRowObject.PurchaseUnitOfMeasure;

								MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
									onClose: function (oAction) {
										if (oAction === MessageBox.Action.OK) {

											//this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
											this.getMainDataUOM(oRowObject.VolumeUOM);
											//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
											setTimeout(function () {
												oTable.getItems()[i].getCells()[0].setValue(ordNo);
												this.otherDataBackendCustRef[i] = {
													salesQty: sPurchaseQty,
													Material: material,
													salesUOM: salesUOM,
													plant: plant,
													sSalesOrderItemNo: sPurchaseOrderItemNo
												};

												oTable.getItems()[i].getCells()[2].setText(ordNo);
												oTable.getItems()[i].getCells()[3].setText(ordQty);
												this.fPlant = plant;
												//this.fIncoTerms = incoTerms;
												//this.fSalesOrg = salesOrg;

												for (var c = 4; c < oTable.getColumns().length - 1; c++) {
													oTable.getItems()[i].getCells()[c].setEditable(true);
													oTable.getItems()[i].getCells()[c].setValue("");
												}
												this.checkRows();
											}.bind(this), 1500);

										} else {
											MessageToast.show("Canceled!!", {
												duration: 500
											});
										}
									}.bind(this)
								});
							} else {
								oTable.getItems()[i].getCells()[0].setValue(ordNo);
								this.otherDataBackendCustRef[i] = {
									salesQty: oRowObject.Quantity,
									Material: oRowObject.Material,
									salesUOM: oRowObject.SalesUnitOfMeasure,
									plant: oRowObject.Plant,
									sSalesOrderItemNo: oRowObject.SalesOrderItemNo
								};

								oTable.getItems()[i].getCells()[2].setText(ordNo);
								oTable.getItems()[i].getCells()[3].setText(ordQty);
								this.fPlant = oRowObject.Plant;
								this.fIncoTerms = oRowObject.IncoTerms;
								this.fSalesOrg = oRowObject.SalesOrg;

								for (var c = 4; c < oTable.getColumns().length - 1; c++) {
									oTable.getItems()[i].getCells()[c].setEditable(true);
									oTable.getItems()[i].getCells()[c].setValue("");
								}

								this.checkRows();

								this.getMainDataUOM(oRowObject.VolumeUOM);

							}
						}.bind(this));
					} else {
						for (var t = 4; t < oTable.getColumns().length - 1; t++) {
							maxFillingCapacity += Number(oTable.getColumns()[t].getHeader().getItems()[1].getText().split(" ")[0]);
						}
						if (Number(oRowObject.QtyInInputUOM) > maxFillingCapacity) {

							ordNo = oRowObject.PurchaseOrderNo;
							ordQty = oRowObject.QtyInInputUOM;
							plant = oRowObject.Plant;
							//var incoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
							//var salesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();
							sPurchaseOrderItemNo = oRowObject.PurchaseOrderItemNo;
							sPurchaseQty = oRowObject.QtyInInputUOM;
							material = oRowObject.Material;
							salesUOM = oRowObject.PurchaseUnitOfMeasure;
							this.getView().setBusy(true);
							MessageBox.confirm("Order Quantity is greater than Truck Capacity. Do you want to Continue" + "?", {
								onClose: function (oAction) {
									if (oAction === MessageBox.Action.OK) {

										//this.getMainDataUOM(oEvent.getParameter("selectedItems")[0].getCells()[11].getText());
										this.getMainDataUOM(oRowObject.VolumeUOM);
										//this.custOrdMainUOM = oEvent.getParameter("selectedItems")[0].getCells()[11].getText();
										setTimeout(function () {
											oTable.getItems()[i].getCells()[0].setValue(ordNo);
											this.otherDataBackendCustRef[i] = {
												salesQty: sPurchaseQty,
												Material: material,
												salesUOM: salesUOM,
												plant: plant,
												sSalesOrderItemNo: sPurchaseOrderItemNo
											};

											oTable.getItems()[i].getCells()[2].setText(ordNo);
											oTable.getItems()[i].getCells()[3].setText(ordQty);
											this.fPlant = plant;
											//this.fIncoTerms = incoTerms;
											//this.fSalesOrg = salesOrg;

											for (var c = 4; c < oTable.getColumns().length - 1; c++) {
												oTable.getItems()[i].getCells()[c].setEditable(true);
												oTable.getItems()[i].getCells()[c].setValue("");
											}
											this.checkRows();
											this.getView().setBusy(false);
										}.bind(this), 1500);

									} else {
										MessageToast.show("Canceled!!", {
											duration: 500
										});
										this.getView().setBusy(false);
									}
								}.bind(this)
							});
						} else {
							oTable.getItems()[i].getCells()[0].setValue(oEvent.getParameter("selectedItems")[0].getCells()[1].getText());
							this.otherDataBackendCustRef[i] = {
								salesQty: oEvent.getParameter("selectedItems")[0].getCells()[7].getText(),
								Material: oEvent.getParameter("selectedItems")[0].getCells()[9].getText(),
								salesUOM: oEvent.getParameter("selectedItems")[0].getCells()[8].getText(),
								plant: oEvent.getParameter("selectedItems")[0].getCells()[4].getText(),
								sSalesOrderItemNo: oEvent.getParameter("selectedItem").getBindingContext("customerInfo").getObject().SalesOrderItemNo
							};

							oTable.getItems()[i].getCells()[2].setText(oEvent.getParameter("selectedItems")[0].getCells()[0].getText());
							oTable.getItems()[i].getCells()[3].setText(oEvent.getParameter("selectedItems")[0].getCells()[2].getText());
							this.fPlant = oEvent.getParameter("selectedItems")[0].getCells()[4].getText();
							this.fIncoTerms = oEvent.getParameter("selectedItems")[0].getCells()[5].getText();
							this.fSalesOrg = oEvent.getParameter("selectedItems")[0].getCells()[6].getText();

							for (var c = 4; c < oTable.getColumns().length - 1; c++) {
								oTable.getItems()[i].getCells()[c].setEditable(true);
								oTable.getItems()[i].getCells()[c].setValue("");
							}

							this.checkRows();

							this.getMainDataUOM(oRowObject.VolumeUOM);

						}
					}

					break;
				}
			}

		},

		onValueHelpCustomerRefPurchase: function (oEvent, ordNum, ordItemNo, x) {

			var oTable = this.byId("compartmentInfoTable");
			/*var sRowId = oEvent.getSource().data();*/

			var oDataModel = this.getView().getModel();
			var sKey = oDataModel.createKey("/ZOGS_TEC_SO_LST", {
				p_is_b2b: x
			});

			var salesOrderFilter = new Filter("SalesOrderNo", FilterOperator.EQ, ordNum);
			var salesOrderItemNoFilter = new Filter("SalesOrderItemNo", FilterOperator.EQ, ordItemNo);

			oDataModel.read(sKey + "/Set", {
				filters: [salesOrderFilter, salesOrderItemNoFilter],
				success: function (res) {
					for (var i = 0; i < oTable.getItems().length; i++) {
						this.getMainDataUOM(res.results[0].VolumeUOM);

						break;
					}

				}.bind(this),
				error: function (err) {
					this.helpCustomerRef.setBusy(false);
					MessageToast.show("Service Error: ZOGS_TEC_SO_LST " + err);
				}.bind(this)
			});

		},

		handleSearchCustRef: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter1 = new Filter("CustomerReference", FilterOperator.Contains, sValue);
			var oFilter2 = new Filter("SalesOrderWithItemNo", FilterOperator.Contains, sValue);
			var oFilter3 = new Filter("QtyInInputUOM", FilterOperator.Contains, sValue);
			var oFilter4 = new Filter("SalesUnitOfMeasure", FilterOperator.Contains, sValue);
			var oFilter5 = new Filter("Plant", FilterOperator.Contains, sValue);
			var oFilter6 = new Filter("IncoTerms", FilterOperator.Contains, sValue);
			var oFilter7 = new Filter("SalesOrg", FilterOperator.Contains, sValue);
			var oFilter8 = new Filter("Material", FilterOperator.Contains, sValue);
			var oFilter9 = new Filter("ShipToPartyName", FilterOperator.Contains, sValue);
			var oFilter10 = new Filter("MaterialDescription", FilterOperator.Contains, sValue);
			var oFilter11 = new Filter("ShippingPoint", FilterOperator.Contains, sValue);

			var aFilter = new Filter([oFilter1, oFilter2, oFilter3, oFilter4, oFilter5, oFilter6, oFilter7, oFilter8, oFilter9, oFilter10, oFilter11],
				false);

			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter(aFilter);

			if (this.fPlant !== "" & this.fPlant !== undefined)
				sap.ui.getCore().byId("custRefValueHelp").setNoDataText(
					"Search either does not exist or not matching with the selected plant: " +
					this.fPlant + " ,sales org: " + this.fSalesOrg + " and IncoTerms: " + this.fIncoTerms);
			else
				sap.ui.getCore().byId("custRefValueHelp").setNoDataText("No Data Found");
		},

		onCreateTrip: function () {
			this.getView().setBusy(true);

			var truckRegFrg = sap.ui.getCore().byId("trukRegFrg").getValue();
			var isoNumFrg = sap.ui.getCore().byId("isoNumFrg").getValue();
			var tankBarIdFrg = sap.ui.getCore().byId("tankBarIdFrg").getValue();
			var inputHelpUOM = sap.ui.getCore().byId("inputHelpUOM").getValue();
			var msg = "Please input above fields!!";
			var sMaxWeight = sap.ui.getCore().byId("MaxWeight").getValue();

			var regexp = new RegExp("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9 ]+)$");
			var regexpFirstChar = new RegExp("^[a-zA-Z]+");
			var getNum;

			if (truckRegFrg === "") {
				sap.ui.getCore().byId("trukRegFrg").setValueState("Error");
				MessageToast.show(msg);
				return;
			} else {
				sap.ui.getCore().byId("trukRegFrg").setValueState("None");
			}

			if (inputHelpUOM === "") {
				sap.ui.getCore().byId("inputHelpUOM").setValueState("Error");
				MessageToast.show(msg);
				return;
			} else {
				sap.ui.getCore().byId("inputHelpUOM").setValueState("None");
			}

			if (tankBarIdFrg === "" & isoNumFrg === "") {
				sap.ui.getCore().byId("tankBarIdFrg").setValueState("Error");
				sap.ui.getCore().byId("isoNumFrg").setValueState("Error");
				MessageToast.show(msg);
				return;
			} else if (isoNumFrg !== "") {
				sap.ui.getCore().byId("tankBarIdFrg").setValueState("None");
				getNum = isoNumFrg.match(/\d/g);
				if (!regexpFirstChar.test(isoNumFrg)) {
					sap.ui.getCore().byId("isoNumFrg").setValueState("Error");
					MessageToast.show("ISO Compartment Number should start from Character!!!");
					return;
				} else if (!regexp.test(isoNumFrg)) {
					sap.ui.getCore().byId("isoNumFrg").setValueState("Error");
					MessageToast.show("ISO Compartment Number should be Alpha Numeric!!!");
					return;
				} else if (getNum.join("").length > 8) {
					sap.ui.getCore().byId("isoNumFrg").setValueState("Error");
					MessageToast.show("ISO Compartment Number Max Numeric allowed is 8 length!!!");
					return;
				} else {
					sap.ui.getCore().byId("isoNumFrg").setValueState("None");
				}
			} else if (tankBarIdFrg !== "") {
				sap.ui.getCore().byId("isoNumFrg").setValueState("None");
				getNum = tankBarIdFrg.match(/\d/g);
				if (!regexpFirstChar.test(tankBarIdFrg)) {
					sap.ui.getCore().byId("tankBarIdFrg").setValueState("Error");
					MessageToast.show("Tank/Barrel ID should start from Character!!!");
					return;
				} else if (!regexp.test(tankBarIdFrg)) {
					sap.ui.getCore().byId("tankBarIdFrg").setValueState("Error");
					MessageToast.show("Tank/Barrel ID should be Alpha Numeric!!!");
					return;
				} else if (getNum.join("").length > 8) {
					sap.ui.getCore().byId("tankBarIdFrg").setValueState("Error");
					MessageToast.show("Tank/Barrel ID Max Numeric allowed is 8 length!!!");
					return;
				} else {
					sap.ui.getCore().byId("tankBarIdFrg").setValueState("None");
				}
			}

			var tableError = false;

			var oTable = sap.ui.getCore().byId("creTripsTbl");
			for (var i = 0; i < oTable.getItems().length; i++) {
				if (oTable.getItems()[i].getCells()[1].getItems()[0].getValue() === "") {
					oTable.getItems()[i].getCells()[1].getItems()[0].setValueState("Error");
					tableError = true;
				} else {
					oTable.getItems()[i].getCells()[1].getItems()[0].setValueState("None");
				}
			}

			if (tableError) {
				return;
			}

			if (oTable.getItems().length === 0) {
				MessageToast.show("Add atleast one Compartment to continue!!!");
				return;
			}

			var arrayData = {};

			if (sMaxWeight === '' || sMaxWeight === null)
				arrayData = {
					TruckNo: truckRegFrg,
					IsoContainer: isoNumFrg,
					TransporterName: sap.ui.getCore().byId("trpNameFrg").getValue(),
					TransporterCode: this.sVendor,
					BarrelID: tankBarIdFrg,
					UOM: inputHelpUOM,
					IsOwnVehicle: (sap.ui.getCore().byId("ownVehicle").getSelected() ? "X" : "")
				};
			else
				arrayData = {
					TruckNo: truckRegFrg,
					IsoContainer: isoNumFrg,
					TransporterName: sap.ui.getCore().byId("trpNameFrg").getValue(),
					TransporterCode: this.sVendor,
					BarrelID: tankBarIdFrg,
					UOM: inputHelpUOM,
					IsOwnVehicle: (sap.ui.getCore().byId("ownVehicle").getSelected() ? "X" : ""),
					MaxWeight: sMaxWeight
				};

			for (var j = 0; j < oTable.getItems().length; j++) {
				arrayData["C" + (j + 1)] = oTable.getItems()[j].getCells()[1].getItems()[0].getValue();
			}

			var oDataModel = this.getView().getModel();

			oDataModel.create("/Trucks", arrayData, {
				success: function (oReq, oRes) {
					this.getView().setBusy(false);
					//MessageToast.show(JSON.parse(oRes.headers["sap-message"]).message);

					var eMsg = JSON.parse(oRes.headers["sap-message"]).message;

					if (JSON.parse(oRes.headers["sap-message"]).details.length !== 0) {
						for (var k = 0; k < JSON.parse(oRes.headers["sap-message"]).details.length; k++) {
							if (!eMsg.includes(JSON.parse(oRes.headers["sap-message"]).details[k].message))
								eMsg += "\n" + JSON.parse(oRes.headers["sap-message"]).details[k].message;
						}
					}
					MessageBox.success(eMsg, {
						actions: [MessageBox.Action.OK]
					});

					for (var l = 0; l < oTable.getItems().length; l++) {
						oTable.removeItem(l);
						l--;
					}

					sap.ui.getCore().byId("trukRegFrg").setValue("");
					sap.ui.getCore().byId("isoNumFrg").setValue("");
					sap.ui.getCore().byId("trpNameFrg").setValue("");
					sap.ui.getCore().byId("tankBarIdFrg").setValue("");
					sap.ui.getCore().byId("inputHelpUOM").setValue("");
					sap.ui.getCore().byId("MaxWeight").setValue("");
					sap.ui.getCore().byId("ownVehicle").setSelected(false);
					this.truckCreationDialog.close();

				}.bind(this),
				error: function (erMsg) {
					this.getView().setBusy(false);
					MessageBox.error(JSON.parse(erMsg.responseText).error.message.value, {
						actions: [MessageBox.Action.OK]
					});
				}.bind(this)
			});

		},

		onOpenTripSearch: function () {

			this.getView().setBusy(true);
			var tripNum = this.byId("tripNum").getValue();
			var truckNumRev = this.byId("truckNumRev").getValue();
			var custOrdNum = this.byId("custOrdNum").getValue();

			if (tripNum === "" & truckNumRev === "" & custOrdNum === "") {
				this.byId("tripNum").setValueState("Error");
				this.byId("truckNumRev").setValueState("Error");
				this.byId("custOrdNum").setValueState("Error");
				var msg = "Please input any of above fields!!";
				MessageToast.show(msg);
				this.getView().setBusy(false);
				return;
			} else {
				this.byId("tripNum").setValueState("None");
				this.byId("truckNumRev").setValueState("None");
				this.byId("custOrdNum").setValueState("None");
			}

			MessageToast.show("Searching...");

			var oModelBackend = this.getView().getModel();
			var jsonModel = new JSONModel();

			var joinTripNCustOrd = tripNum + "/" + custOrdNum;
			var checkData = joinTripNCustOrd.split("/");
			var checkDataBool = false;

			for (var i = 0; i < joinTripNCustOrd.split("/").length; i++) {
				if (checkData[i].trim() !== "") {
					checkDataBool = true;
				}
			}

			if (checkDataBool === false) {
				joinTripNCustOrd = "";
			}

			var sKey = oModelBackend.createKey("/Trucks", {
				TruckNo: truckNumRev,
				IsoContainer: joinTripNCustOrd,
				InputUom: ""
			});

			oModelBackend.read(sKey, {
				urlParameters: {
					"$expand": "Trips"
				},
				success: function (oRes) {
					this.getView().setBusy(false);
					this.byId("openTripsTbl").setVisible(true);
					this.byId("overFlowFt").setVisible(true);
					//MessageToast.show(oRes);

					this.byId("btnCreateTrip").setVisible(false);
					this.byId("btnVal").setVisible(false);
					this.byId("btnCnTrip").setVisible(true);

					this.tripRDriverNm = oRes.DriverName;
					this.tripRTotalVol = oRes.TotalVolume;
					this.tripRNoComp = oRes.NoOfCompartments;
					this.tripRTruckNo = oRes.TruckNo;
					this.tripRUOM = oRes.UOM;

					var oTable = this.byId("openTripsTbl");
					var count = 1;
					for (var j = 3; j < oTable.getColumns().length; j++) {
						if (oRes["SalesOrder" + count + "Flag"]) {
							oTable.getColumns()[j].setVisible(true);
						} else {
							oTable.getColumns()[j].setVisible(false);
						}
						count++;
					}

					jsonModel.setData(oRes.Trips.results);
					this.getView().setModel(jsonModel, "tripInfo");
				}.bind(this),
				error: function (oErr) {
					this.getView().setBusy(false);
					MessageToast.show(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});

		},

		onPressCreateTruck: function () {

			/*if (this.byId("truckNum").getValue().trim() === "") {
				MessageToast.show("Please enter valid Truck Number for Create Truck!!!");
				this.byId("truckNum").setValueState("Error");
				return;
			} else {
				this.byId("truckNum").setValueState("None");
			}*/

			if (!this.truckCreationDialog) {
				this.truckCreationDialog = sap.ui.xmlfragment(
					"ZEasy_Creation.ZEasy_Creation.Fragments.TruckCreation",
					this
				);
				this.getView().addDependent(this.truckCreationDialog);
			}

			//newTruckCreation
			/*var oModelTripTable = new JSONModel();
			oModelTripTable.setData({
				compartment: [{
					compartment_name: "C1"
				}, {
					compartment_name: "C2"
				}, {
					compartment_name: "C3"
				}, {
					compartment_name: "C4"
				}]
			});
			this.getView().setModel(oModelTripTable, "newTruckCreation");*/

			this.truckCreationDialog.open();

			sap.ui.getCore().byId("trukRegFrg").setValue(this.byId("truckNum").getValue());
			sap.ui.getCore().byId("isoNumFrg").setValue(this.byId("isoNum").getValue());
			//sap.ui.getCore().byId("trpNameFrg").setValue(this.byId("driverNum").getValue());

			for (var i = 0; i < 4; i++) {
				this.onPressAddRow("");
			}
		},

		onFragCancel: function () {
			MessageBox.confirm("Unsaved Data will be lost. Do you want to Continue" + "?", {
				onClose: function (oAction) {
					if (oAction === MessageBox.Action.OK) {

						sap.ui.getCore().byId("trukRegFrg").setValueState("None");
						sap.ui.getCore().byId("isoNumFrg").setValueState("None");
						sap.ui.getCore().byId("tankBarIdFrg").setValueState("None");
						sap.ui.getCore().byId("inputHelpUOM").setValueState("None");

						sap.ui.getCore().byId("trukRegFrg").setValue("");
						sap.ui.getCore().byId("isoNumFrg").setValue("");
						sap.ui.getCore().byId("trpNameFrg").setValue("");
						sap.ui.getCore().byId("tankBarIdFrg").setValue("");
						sap.ui.getCore().byId("inputHelpUOM").setValue("");

						var oTable = sap.ui.getCore().byId("creTripsTbl");
						for (var i = 0; i < oTable.getItems().length; i++) {
							oTable.removeItem(i);
							i--;
						}

						this.truckCreationDialog.close();
						this.getView().setBusy(false);
					} else {
						MessageToast.show("Canceled!!", {
							duration: 500
						});
					}
				}.bind(this)
			});

		},

		onDeleteMainTableRow: function (oEvent) {
			var oRow = oEvent.getSource().getParent();
			var oTable = oRow.getParent();
			var oIndex = oTable.indexOfItem(oRow);
			oTable.removeItem(oIndex);
			delete this.oSalesOrders[oRow.getCells()[2].getText()];
			this.checkRows();
		},

		onPressAddRowMain: function () {
			var oTable = this.byId("compartmentInfoTable");
			var oTableLength = oTable.getItems().length;

			var noOfRowAllowed = oTable.getColumns().length - 5;

			if (oTableLength === noOfRowAllowed) {
				MessageToast.show("Maximum " + noOfRowAllowed + " line Items are allowed!!");
				return;
			}

			var oCell = [];

			for (var k = 0; k < (4 + this.noOfCompartments); k++) {

				if (k === 0) {
					oCell.push(new sap.m.Input({
						value: "",
						showValueHelp: true,
						valueHelpRequest: [this.onValueHelpMainOkPress, this],
						valueHelpOnly: true
					}));
				}

				if (k === 2) {
					oCell.push(new sap.m.MultiInput({
						showValueHelp: true,
						valueHelpRequest: [this.onValueHelpPurchase, this],
						valueHelpOnly: true,
						tokenUpdate: [this.onTokenUpdate, this]
					}));
				}

				if (k !== 1 & k !== 0 & k !== 2 & k !== 3) {
					oCell.push(new sap.m.Input({
						value: "",
						width: "7em",
						type: "Text",
						liveChange: [this.onQtyChange, this],
						editable: false
					}));
				}
				if (k === 1 || k === 2) {
					oCell.push(new sap.m.Text({
						text: ""
					}));
				}

				if (k === (3 + this.noOfCompartments)) {
					oCell.push(new sap.ui.core.Icon({
						src: "sap-icon://delete",
						press: [this.onDeleteMainTableRow, this]
					}));
				}

				var aColList = new sap.m.ColumnListItem({
					cells: oCell
				});
			}
			oTable.addItem(aColList);

		},

		onPressAddRow: function (fillingCapacity) {
			var table = sap.ui.getCore().byId("creTripsTbl");
			var oTableLength = table.getItems().length;

			if (oTableLength === 7) {
				MessageToast.show("Maximum 7 Compartment are allowed!!");
				return;
			}

			if (this.valueOfUOM === undefined) {
				this.valueOfUOM = "";
			}

			if (sap.ui.getCore().byId("inputHelpUOM").getValue() !== "") {
				this.valueOfUOM = sap.ui.getCore().byId("inputHelpUOM").getValue();
			}

			var oItem = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
					text: "C" + (oTableLength + 1)
				}), new sap.m.FlexBox({
					alignItems: "Center",
					justifyContent: "Center",
					items: [new sap.m.Input({
							value: fillingCapacity,
							maxLength: 10,
							liveChange: [this.onFillingCapacityChange]
						}),
						new sap.m.Text({
							text: this.valueOfUOM
						})
					]
				}), new sap.ui.core.Icon({
					src: "sap-icon://delete",
					press: [this.onDeleteRow]
				})]
			});

			table.addItem(oItem);
		},

		onFillingCapacityChange: function (oEvent) {
			if (/([1-9]\d*(\.\d*[1-9])?|0\.\d*[1-9]+)|\d+(\.\d*[1-9])?/.test(parseFloat(oEvent.getSource().getValue()))) {
				oEvent.getSource().setValue(oEvent.getSource().getValue());
			} else {
				oEvent.getSource().setValue("");
			}
		},

		onDeleteRow: function (oEvent) {
			var oRow = oEvent.getSource().getParent();
			var oTable = oRow.getParent();
			var oIndex = oTable.indexOfItem(oRow);
			var oTableInfo = sap.ui.getCore().byId("creTripsTbl");
			var oTableLastCount = oTableInfo.getItems().length;

			if (oIndex === oTableLastCount - 1)
				oTable.removeItem(oIndex);
			else
				MessageBox.confirm("Table will be reset. Do you want to Continue" + "?", {
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.OK) {

							oTable.removeItem(oIndex);
							oTableLastCount = oTableInfo.getItems().length;
							var tableFillingCapacity = [];
							if (oTableLastCount !== oIndex) {
								for (var i = 0; i < oTable.getItems().length; i++) {
									tableFillingCapacity.push(oTableInfo.getItems()[i].getCells()[1].getItems()[0].getValue());
									oTableInfo.removeItem(i);
									i--;
								}
								for (var j = 0; j < oTableLastCount; j++) {
									sap.ui.controller("ZEasy_Creation.ZEasy_Creation.controller.Main").
									onPressAddRow(tableFillingCapacity[j]);
								}
							}
						} else {
							MessageToast.show("Canceled!!", {
								duration: 500
							});
						}
					}.bind(this)
				});

		},

		onValueHelpRequested: function () {

			var oValHelpModel = new JSONModel();
			var oModel = this.getView().getModel();

			oModel.read("/ZOGS_TEC_UOM_LST", {
				success: function (res) {
					oValHelpModel.setData(res.results);
					this.getView().setModel(oValHelpModel, "truckCreationUOM");
				}.bind(this),
				error: function (err) {
					MessageToast.show("Service Failed: ZOGS_TEC_UOM_LST" + err);
				}
			});

			if (!this.valueHelpDialog) {
				this.valueHelpDialog = sap.ui.xmlfragment(
					"ZEasy_Creation.ZEasy_Creation.Fragments.ValueHelpDialogBasic",
					this
				);
				this.getView().addDependent(this.valueHelpDialog);
			}

			this.valueHelpDialog.open();
		},

		onValueHelpOkPress: function (oEvent) {
			this.valueOfUOM = oEvent.getParameter("selectedItems")[0].getCells()[0].getText();
			sap.ui.getCore().byId("inputHelpUOM").setValue(this.valueOfUOM);

			var oTable = sap.ui.getCore().byId("creTripsTbl");
			var oTableLength = oTable.getItems().length;

			for (var i = 0; i < oTableLength; i++) {
				oTable.getItems()[i].getCells()[1].getItems()[1].setText(this.valueOfUOM);
			}

		},

		handleSearch: function (oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilter1 = new Filter("UnitOfMeasure", FilterOperator.Contains, sValue);
			var oFilter2 = new Filter("UnitOfMeasureTxt", FilterOperator.Contains, sValue);
			var aFilter = new Filter([oFilter1, oFilter2], false);

			var oBinding = oEvent.getSource().getBinding("items");

			oBinding.filter(aFilter);
		},

		handleIconTabBarSelect: function (oEvent) {
			if (oEvent !== undefined) {
				var sKey = oEvent.getParameter("key");

				// debugger;
				// if (this.selectTab !== undefined){
				// 	if (sKey === this.selectTab) {
				// 		return;
				// 	}
				// }else{
				// 	this.selectTab = sKey;
				// }

				if (this.byId("compartmentInfoTable").getVisible() || this.byId("openTripsTbl").getVisible())
					MessageBox.confirm("Unsaved Data will be lost. Do you want to Continue" + "?", {
						onClose: function (oAction) {
							if (oAction === MessageBox.Action.OK) {
								if (sKey === "Rev") {
									this.selectTab = "Rev";
									this.byId("truckNum").setValue("");
									this.byId("isoNum").setValue("");
									//this.byId("driverNum").setValue("");

									this.byId("btnCreateTrip").setVisible(false);
									this.byId("btnVal").setVisible(false);
									this.byId("btnCnTrip").setVisible(true);

									this.byId("compartmentInfoTable").setVisible(false);

									this.byId("overFlowFt").setVisible(false);
								} else {
									this.selectTab = "Reg";
									this.byId("tripNum").setValue("");
									this.byId("truckNumRev").setValue("");
									this.byId("custOrdNum").setValue("");
									this.byId("driverName").setValue("");

									this.byId("btnCreateTrip").setVisible(true);
									this.byId("btnVal").setVisible(true);
									this.byId("btnCnTrip").setVisible(false);

									this.byId("openTripsTbl").setVisible(false);
									this.byId("overFlowFt").setVisible(false);

									this.byId("compartmentInfoTable").setVisible(false);
									this.byId("truckNum").setValue("");
									this.byId("isoNum").setValue("");
									//this.byId("driverNum").setValue("");
								}
							} else {
								if (sKey === "Rev") {
									this.byId("tabBar").setSelectedKey("Reg");
									this.selectTab = "Reg";
								} else {
									this.byId("tabBar").setSelectedKey("Rev");
									this.selectTab = "Rev";
								}

								MessageToast.show("Canceled!!", {
									duration: 500
								});
							}
						}.bind(this)
					});
			} else {
				this.selectTab = "Reg";
				this.byId("tripNum").setValue("");
				this.byId("truckNumRev").setValue("");
				this.byId("custOrdNum").setValue("");
				this.byId("driverName").setValue("");

				this.byId("btnCreateTrip").setVisible(true);
				this.byId("btnVal").setVisible(true);
				this.byId("btnCnTrip").setVisible(false);

				this.byId("openTripsTbl").setVisible(false);
				this.byId("overFlowFt").setVisible(false);

				this.byId("compartmentInfoTable").setVisible(false);
				this.byId("truckNum").setValue("");
				this.byId("isoNum").setValue("");
			}

		},

		onPressValidate: function () {
			this.sendDataBackend("VALIDATE");
		},

		onPressSave: function () {
			this.sendDataBackend("SAVE");
		},

		sendDataBackend: function (oType) {

			var oTable = this.byId("compartmentInfoTable");
			if (oTable.getItems().length === 0) {
				MessageToast.show("Please create atleast one line item to continue!!!");
				return;
			}
			for (var i = 0; i < oTable.getItems().length; i++) {
				if (oTable.getItems()[i].getCells()[2].getText() === "") {
					MessageToast.show("Please input valid Customer Reference!!!");
					oTable.getItems()[i].getCells()[0].setValueState("Error");
					return;
				} else {
					oTable.getItems()[i].getCells()[0].setValueState("None");
				}
			}

			var checkValue = true;

			for (var p = 0; p < oTable.getItems().length; p++) {
				checkValue = true;
				for (var j = 4; j < oTable.getColumns().length - 1; j++) {
					var k = oTable.getItems()[p].getCells()[j].getValue();
					if (k !== "") {
						checkValue = false;
					} else {
						oTable.getItems()[p].getCells()[j].setValueState("Error");
					}
				}
				if (!checkValue)
					for (var z = 0; z < oTable.getItems().length; z++) {
						for (var t = 4; t < oTable.getColumns().length - 1; t++) {
							oTable.getItems()[z].getCells()[t].setValueState("None");
						}
					}

				if (checkValue) {
					MessageToast.show("Please fill atleast one Compartment Value to continue!! \n" +
						"or Remove empty compartment row to continue!!");
					return;
				}
			}

			this.getView().setBusy(true);

			var oModelBackend = this.getView().getModel();

			var dataBackend = {
				DriverCode: this.sDriver,
				TotalVolume: this.totalVol,
				NoOfCompartments: this.noOfCompartments,
				TruckNo: this.truckNum,
				UOM: this.uom,
				CallingFor: oType,
				IsoContainer: this.isoNum,
				Orders: []
			};
			if (this.bSTOFlag) {
				dataBackend.Zpoflag = "X";
			}

			var noOfColumns = oTable.getColumns().length;
			for (var i = 0; i < oTable.getItems().length; i++) {

				var docNum = "";
				var docType = "";

				if (oTable.getItems()[i].getCells()[1].getTokens().length > 0) {
					docNum = oTable.getItems()[i].getCells()[1].getTokens()[0].getText();
					docType = oTable.getItems()[i].getCells()[1].getTokens()[0].getKey();
				}

				dataBackend.Orders[i] = {
					SalesOrderNo: (oTable.getItems()[i].getCells()[0].getValue().split("("))[0],
					DocNumber: docNum,
					DocType: docType,
					TripNumber: "",
					Material: this.otherDataBackendCustRef[i].Material,
					SalesQty: this.otherDataBackendCustRef[i].salesQty,
					SalesUOM: this.otherDataBackendCustRef[i].salesUOM,
					Plant: this.otherDataBackendCustRef[i].plant,
					SalesOrderItemNo: this.otherDataBackendCustRef[i].sSalesOrderItemNo
				};
				var noOfComp = 1;
				for (var c = 4; c < noOfColumns - 1; c++) {

					if (oTable.getItems()[i].getCells()[c].getValue().trim() !== "")
						dataBackend.Orders[i]["C" + (noOfComp)] = oTable.getItems()[i].getCells()[c].getValue();
					else
						dataBackend.Orders[i]["C" + (noOfComp)] = "0.000";

					noOfComp++;
				}
				for (var z = noOfComp; z < 9; z++) {
					dataBackend.Orders[i]["C" + (noOfComp)] = "0.000";
					noOfComp++;
				}
			}

			oModelBackend.create("/Trucks", dataBackend, {
				success: function (oReq, oRes) {
					this.getView().setBusy(false);
					if (oType === "SAVE") {
						//MessageToast.show("Created!!");
						// MessageBox.confirm("Created!!", {
						// 	actions: [MessageBox.Action.OK]
						// });
						var eMsg = JSON.parse(oRes.headers["sap-message"]).message;

						if (JSON.parse(oRes.headers["sap-message"]).details.length !== 0) {
							for (var k = 0; k < JSON.parse(oRes.headers["sap-message"]).details.length; k++) {
								if (!eMsg.includes(JSON.parse(oRes.headers["sap-message"]).details[k].message))
									eMsg += "\n" + JSON.parse(oRes.headers["sap-message"]).details[k].message + "\n";
							}
						}
						MessageBox.success(eMsg, {
							actions: [MessageBox.Action.OK]
						});
						this.handleIconTabBarSelect();
					} else {
						//MessageToast.show("Validation Success!!");
						MessageBox.success("Validation Success!!", {
							actions: [MessageBox.Action.OK]
						});
					}
				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);
					var msg = JSON.parse(eMsg.responseText).error.message.value;

					if (JSON.parse(eMsg.responseText).error.innererror.errordetails.length > 0) {
						msg = "";
						for (var k = 0; k < JSON.parse(eMsg.responseText).error.innererror.errordetails.length - 1; k++) {
							if (!msg.includes(JSON.parse(eMsg.responseText).error.innererror.errordetails[k].message))
								msg += JSON.parse(eMsg.responseText).error.innererror.errordetails[k].message + "\n";
						}
					}

					MessageBox.error(msg, {
						actions: [MessageBox.Action.OK]
					});
				}.bind(this)
			});

		},

		onPressReject: function () {

			this.getView().setBusy(true);

			var oModelBackend = this.getView().getModel();

			var dataBackend = {
				DriverName: this.tripRDriverNm,
				TotalVolume: this.tripRTotalVol,
				NoOfCompartments: this.tripRNoComp,
				TruckNo: this.tripRTruckNo,
				UOM: this.tripRUOM,
				CallingFor: "DELETE",
				Orders: []
			};

			var oTable = this.byId("openTripsTbl");

			if (oTable.getSelectedItems().length === 0) {
				MessageToast.show("Please select atlease one row to process!!");
				this.getView().setBusy(false);
				return;
			}

			for (var i = 0; i < oTable.getSelectedItems().length; i++) {
				dataBackend.Orders[i] = {
					SalesOrderNo: "",
					TripNumber: oTable.getSelectedItems()[i].getCells()[0].getText()
				};
				var noOfComp = 1;
				for (var z = 0; z < 5; z++) {
					dataBackend.Orders[i]["C" + (noOfComp)] = "0.000";
					noOfComp++;
				}
			}

			oModelBackend.create("/Trucks", dataBackend, {
				success: function (oReq, oRes) {
					this.getView().setBusy(false);

					var successMsg = JSON.parse(oRes.headers["sap-message"]).message;

					var aTripData = this.getView().getModel("tripInfo").getData();

					var tripNo = [];

					for (var t = 0; t < oTable.getItems().length; t++) {
						if (Number(oTable.getItems()[t].getCells()[0].getText()) === Number(successMsg.match(/(\d+)/)[0])) {
							aTripData.splice(t, 1);
							t--;
							break;
						}
					}

					if (JSON.parse(oRes.headers["sap-message"]).details.length > 0) {
						successMsg += "\n";
						for (var y = 0; y < JSON.parse(oRes.headers["sap-message"]).details.length; y++) {
							successMsg += JSON.parse(oRes.headers["sap-message"]).details[y].message;
							try {
								tripNo.push(JSON.parse(oRes.headers["sap-message"]).details[y].message.match(/(\d+)/)[0]);
							} catch (exce) {

							}
						}
						for (var r = 0; r < aTripData.length; r++) {
							if (tripNo.includes(aTripData[r].TripNo)) {
								aTripData.splice(r, 1);
								r--;
							}
						}
					}

					this.getView().getModel("tripInfo").setData(aTripData);
					oTable.removeSelections();

					MessageBox.success(successMsg, {
						actions: [MessageBox.Action.OK]
					});

				}.bind(this),
				error: function (eMsg) {
					this.getView().setBusy(false);

					var errMsg = "";
					var tripNo = [];
					for (var x = 0; x < JSON.parse(eMsg.responseText).error.innererror.errordetails.length - 1; x++) {
						if (!errMsg.includes(JSON.parse(eMsg.responseText).error.innererror.errordetails[x].message)) {
							errMsg += JSON.parse(eMsg.responseText).error.innererror.errordetails[x].message + "\n";
							try {
								tripNo.push(JSON.parse(eMsg.responseText).error.innererror.errordetails[x].message.match(/(\d+)/)[0]);
							} catch (excep) {

							}
						}
					}

					var aTripData = this.getView().getModel("tripInfo").getData();

					for (var r = 0; r < aTripData.length; r++) {
						if (tripNo.includes(aTripData[r].TripNo)) {
							aTripData.splice(r, 1);
							r--;
						}
					}

					this.getView().getModel("tripInfo").setData(aTripData);

					try {
						oTable.removeSelections();
						//	MessageToast.show(errMsg);
					} catch (err) {
						//	MessageToast.show(errMsg);
						//MessageToast.show(JSON.parse(eMsg.responseText).error.message.value);
					}

					MessageBox.error(errMsg, {
						actions: [MessageBox.Action.OK]
					});

				}.bind(this)
			});
		},

		checkRows: function () {

			var oTable = this.byId("compartmentInfoTable");
			var oTableLength = oTable.getItems().length;
			var skip = false;

			for (var c = 4; c < oTable.getColumns().length - 1; c++) {
				skip = false;
				for (var r = 0; r < oTableLength; r++) {
					if (oTable.getItems()[r].getCells()[c].getValue() !== "") {
						skip = true;
						for (var a = 0; a < oTableLength; a++) {
							if (a !== r) {
								oTable.getItems()[a].getCells()[c].setEditable(false);
							}
						}
					}
					if (!skip & oTable.getItems()[r].getCells()[2].getText() !== "") {
						for (var z = c; z < oTable.getColumns().length - 1; z++) {
							oTable.getItems()[r].getCells()[z].setEditable(true);
						}
					}
				}
			}

			/*for (var r = 0; r < oTableLength; r++) {
				for (var c = 4; c < oTable.getColumns().length - 1; c++) {
					if (oTable.getItems()[r].getCells()[c].getValue() !== "") {
						skip = true;
						for (var a = 0; a < oTableLength; a++) {
							if (a !== r)
								oTable.getItems()[a].getCells()[c].setEditable(false);
						}
					}
				}
				if (!skip) {
					for (c = 4; c < oTable.getColumns().length - 1; c++) {
						oTable.getItems()[r].getCells()[c].setEditable(true);
					}
				}
			}*/
		},

		onQtyChange: function (oEvent) {
			oEvent.getSource().setValue(oEvent.getSource().getValue().replace(/^0+/, ''));
			oEvent.getSource().setValue(oEvent.getSource().getValue().replace(/[^0-9]/g, ''));

			var oTable = this.byId("compartmentInfoTable");
			var oTableLength = oTable.getItems().length;

			for (var i = 0; i < oTableLength; i++) {
				if (oEvent.getSource().getParent().getId() === oTable.getItems()[i].getId()) {

					this.checkRows();

					var oQty = Number(oTable.getItems()[i].getCells()[3].getText());
					var totalSum = 0;

					for (var c = 4; c < oTable.getColumns().length - 1; c++) {
						totalSum += Number(oTable.getItems()[i].getCells()[c].getValue());
					}

					if (totalSum > oQty) {
						oEvent.getSource().setValueState("Error");
						MessageToast.show("Compatment Quantity is Greater than allowed!!");
						this.byId("btnCreateTrip").setEnabled(false);
						this.byId("btnVal").setEnabled(false);
						return;
					} else {
						oEvent.getSource().setValueState("None");
						this.byId("btnCreateTrip").setEnabled(true);
						this.byId("btnVal").setEnabled(true);
					}

					var maxColumnQty = 0;
					var totalColumnSum = 0;

					for (var r = 0; r < oTable.getItems()[i].getCells().length; r++) {
						if (oEvent.getSource().getId() === oTable.getItems()[i].getCells()[r].getId()) {
							maxColumnQty = Number(oTable.getColumns()[r].getHeader().getItems()[1].getText().split(" ")[0]);
							break;
						}
					}

					for (var s = 0; s < oTable.getItems().length; s++) {
						totalColumnSum += Number(oTable.getItems()[s].getCells()[r].getValue());
					}

					if (totalColumnSum > maxColumnQty) {
						oEvent.getSource().setValueState("Error");
						this.byId("btnCreateTrip").setEnabled(false);
						this.byId("btnVal").setEnabled(false);
						MessageToast.show("Compatment Quantity is Greater than allowed!!");
					} else {
						oEvent.getSource().setValueState("None");
						this.byId("btnCreateTrip").setEnabled(true);
						this.byId("btnVal").setEnabled(true);
					}
					break;
				}
			}

		},

		onChangeFilterVal: function () {
			if (this.byId("compartmentInfoTable").getVisible())
				MessageBox.confirm("If you change this you need to search again. Do you want to Continue" + "?", {
					onClose: function (oAction) {
						if (oAction === MessageBox.Action.OK) {
							this.searchAgain = false;
							this.byId("compartmentInfoTable").setVisible(false);
							this.byId("overFlowFt").setVisible(false);
						} else {
							this.byId("truckNum").setValue(this.truckNum);
							this.byId("isoNum").setValue(this.isoNum);
							//this.byId("driverNum").setValue(this.driverFilterVal);
							MessageToast.show("Canceled!!", {
								duration: 500
							});
							return;
						}
					}.bind(this)
				});
		}
	});
});