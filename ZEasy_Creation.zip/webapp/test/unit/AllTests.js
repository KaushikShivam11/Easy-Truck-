sap.ui.define([
	"ZEasy_Creation/ZEasy_Creation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});